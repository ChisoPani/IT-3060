'use strict';
// membership.js
// This script calculates the cost of a membership.

// Function called when the form is submitted.
// Function performs the calculation and returns false.
function calculate() {
  
    // TODO declare a variable named 'cost' to store the total cost:
    let cost;

    // TODO lookup the type and years input elements with DOM getElementById()
    let type = document.getElementById("type");
    let years = document.getElementById("years");

    // TODO Convert the year to a number (see parseInt())
    if (years && years.value) {
        years = parseInt(years.value, 10);
    }

    // Check for valid data:
    if (type && type.value && years && (years > 0)) {

        // TODO Add a switch statement to determine the base cost using the value of "type"
        switch (type.value) {
            case 'basic':
                cost = 10;
                break;
            case 'premium':
                cost = 15;
                break;
            case 'gold':
                cost = 20;
                break;
            case 'platinum':
                cost = 25;
                break;
        }

        // TODO Update cost by multiplying number of years
        cost = cost * years;
        // Discount multiple years
        if (years > 1) {
            cost *= 0.80; // 80%
        }
        // TODO convert cost to a number and then format to decimal places (see Number.toFixed())
        cost = "$" + cost + ".00"
        let costElement = document.getElementById('cost');

        // TODO update the value property of 'costElement' to the calculated cost
         costElement.value = cost;
       
    }   
    // Return false to prevent submission:
    return false;
}
function init() {
    document.getElementById('theForm').onsubmit = calculate;
}
window.onload = init;